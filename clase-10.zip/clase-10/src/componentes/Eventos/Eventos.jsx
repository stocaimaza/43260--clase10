/** EVENTOS **/

//1) Eventos manuales. 
//2) Eventos automáticos. 

/*

const titulo = document.get

titulo.addEventListener("click", () => {
    console.log("HOla mundo");
})


////////

titulo.onClick = () => {
    console.log("Hola loco ayudame");
}

/////

<button onClick = "funcion()"></button>


*/

//EVENTOS MÁS UTILIZADOS. 

import { useState } from 'react';
import './Eventos.css'

const Eventos = () => {
    const [input, setInput] = useState("");

    //handler = manejador de eventos

    const manejadorClick = () => {
        console.log("click");
    }

    const manejadorInput = (event) => {
        //Voy a trabajar con el objeto "event"
        setInput(event.target.value);
        //La propiedd target es la referencia al objeto del DOM que dispara el EVENTO. 

        console.log(input);
    }



  return (
    <>
        <button onClick={manejadorClick}> Haceme Click</button>

        <div className="caja"
            onMouseMove={()=> console.log("Nuevo evento, pasaste por la caja")}
            onMouseEnter={()=> console.log("Entraste")}
            onMouseLeave={()=> console.log("Saliste")}
            >

        </div>


        <form>
            <h2> {input } </h2>
            <label htmlFor="campo"> Ingrese texto </label>
            <input type="text" id='campo' 
                onChange={manejadorInput}
                onKeyDown={()=> console.log("Presionaste una tecla")}
                onKeyUp={()=> console.log("Soltaste una tecla")}
            
            />

            {/* htmlFor = es igual al for que usamos en HTML 
            change =  se dispara cuando el usuario cambia el valor del input*/}


        </form>

    </>
  )
}

export default Eventos

//onEventoDeseado