/** EVENTO PARA EL FORMULARIO **/

//onSubmit

import { useState } from "react";
import './Formulario.css';

const Formulario = () => {
    const [nombre, setNombre] = useState("");
    const [apellido, setApellido] = useState("");

    const manejadorSubmit = (event) => {
        //Prevenimos la recarga de la página.
        event.preventDefault();

        const nuevoCliente  = {nombre, apellido};
        console.log(nuevoCliente); 

        setNombre("");
        setApellido("");

    }

  return (
    <form onSubmit={manejadorSubmit}>
        <label htmlFor="nombre"> Nombre </label>
        <input type="text" id="nombre" onChange={(e)=> setNombre(e.target.value)} value={nombre}/>

        <label htmlFor="apellido"> Apellido </label>
        <input type="text" id="apellido" onChange={(e)=> setApellido(e.target.value)} value={apellido}/>

        <button type="submit"> Enviar Datos </button>

    </form>
  )
}

export default Formulario