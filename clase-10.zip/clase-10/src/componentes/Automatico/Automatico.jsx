import { useState, useEffect } from "react"

const Automatico = () => {
    const [mostrarMensaje, setMostrarMensaje] = useState(false);

    useEffect( () => {
        let tiempoEspera = null; 

        const reiniciarTemporizador = () => {
            clearTimeout(tiempoEspera);
            tiempoEspera = setTimeout( () => {
                setMostrarMensaje(true);
            }, 5000) //Tiempo de espera en milisegundos (5 segundos en este caso)
        }

        const manejarActividadUsuario = () => {
            reiniciarTemporizador();
        }

        window.addEventListener("mousemove", manejarActividadUsuario);
        window.addEventListener("keydown", manejarActividadUsuario);

        reiniciarTemporizador();

        return () => {
            window.removeEventListener("mousemove", manejarActividadUsuario);
            window.removeEventListener("keydown", manejarActividadUsuario);
            clearTimeout(tiempoEspera);
        }

    }, [])

    const seguirMirando = () => {
        setMostrarMensaje(false);
    }

  return (
    <div>
        {
            mostrarMensaje && (
                <div>
                    <p> ¿Sigues ahí? </p>
                    <button onClick={seguirMirando}> Seguir mirando</button>
                </div>
            )
        }
        <h2> Contenido de Netflis </h2>
        <p> Tu serie favorita </p>
    </div>
  )
}

export default Automatico