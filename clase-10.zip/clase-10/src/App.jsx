//import Eventos from "./componentes/Eventos/Eventos"
//import Formulario from "./componentes/Formulario/Formulario"
import Automatico from "./componentes/Automatico/Automatico"

const App = () => {
  return (
    <div>
      <h1>Hola Casi es viernes</h1>
      <Automatico/>
      
    </div>
  )
}

export default App